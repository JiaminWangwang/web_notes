interface Debug {
  mainPath: (string) => any;
}

declare var debug: Debug;
